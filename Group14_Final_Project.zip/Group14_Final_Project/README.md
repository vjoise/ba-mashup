ba-mashup
=========

Mashup project with multiple datasets and domains.
=========
Folder Structure
=========

Scrapers - All python scripts used for data collection for CEO profile and company data 

R-scripts - contains R scripts used for data analysis

csv data - contains all final csv used 

starting_csv - contains all the initial csv to start scraping. List of S&P 500 companies


 